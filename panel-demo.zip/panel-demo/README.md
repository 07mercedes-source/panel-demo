Panel Demo - Minimal Next.js demo for Depo / IK / Restoran.

Test kullanıcılar:
- admin / 12345
- muhasebe / 12345
- personel / 12345

Deploy: Vercel recommended.
